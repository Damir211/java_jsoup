package tsn_java_jsoup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class TSN_JAVA_JSOUP {

    public static void main(String[] args) throws IOException {
        try {
            String BASE_URL = "https://www.google.com/search?q=%D1%82%D0%B5%D0%BC%D0%BF%D0%B5%D1%80%D0%B0%D1%82%D1%83%D1%80%D0%B0+%D0%BF%D0%B0%D0%B2%D0%BB%D0%BE%D0%B4%D0%B0%D1%80&rlz=1C1SQJL_ruKZ813KZ813&oq=%D1%82%D0%B5%D0%BC%D0%BF%D0%B5%D1%80%D0%B0%D1%82%D1%83%D1%80%D0%B0+%D0%BF%D0%B0%D0%B2%D0%BB%D0%BE%D0%B4%D0%B0%D1%80&aqs=chrome..69i57j69i61l3j0l2.5929j1j4&sourceid=chrome&ie=UTF-8"; // Адрес с погодой
            StringBuilder data = new StringBuilder();
            Document doc = Jsoup.connect(BASE_URL).timeout(5000).get(); // Создание документа JSOUP из html
            data.append("Прогноз погоды на сегодня:\n"); // Заголовок
            
            data.append(String.format("%12s", "Температура: "));//Заголовок
            Elements temperatura = doc.select("span#wob_tm"); // Нахождение элемента с данными
            data.append(String.format("%12s ", temperatura.text()));// Вывод данных с элемента
            data.append("\n");
            
            data.append(String.format("%13s", "Осадки: "));//Заголовок
            Elements osadki = doc.select("span#wob_pp"); // Нахождение элемента с данными
            data.append(String.format("%12s ", osadki.text()));// Вывод данных с элемента
            data.append("\n");
            
            data.append(String.format("%13s", "Влажность: "));//Заголовок
            Elements vlazhnost = doc.select("span#wob_hm");// Нахождение элемента с данными
            data.append(String.format("%12s ", vlazhnost.text()));// Вывод данных с элемента
            data.append("\n");
            
            data.append(String.format("%13s", "Ветер: "));//Заголовок
            Elements veter = doc.select("span#wob_ws");// Нахождение элемента с данными
            data.append(String.format("%12s ", veter.text()));// Вывод данных с элемента

            System.out.println(data.toString());//вывод данных
        } catch (Exception e) {
            System.out.println("Error!");
        }
    }
}
