# TSN_JAVA_JSOUP
Простейший пример работы с Интернетом с помощью JSOUP на Java в NetBeans 
![srcreenshot](screenshot.png)
